from django.shortcuts import render
from .models import Product
from django.http import HttpResponse
def feedbackform(request):
    return render(request,'feedback.html')
def feedback(request):
    namefeild1=request.GET['namefeild']
    emailfeild1=request.GET['emailfeild']
    feedbackarea1=request.GET['feedbackarea']
    f=Product(namefeild=namefeild1,emailfeild=emailfeild1,feedbackarea=feedbackarea1)
    f.save()
    return HttpResponse("data inserted successfully")

def display(request):
    recs=Product.objects.all()
    return render(request,'display.html',{'records':recs})



