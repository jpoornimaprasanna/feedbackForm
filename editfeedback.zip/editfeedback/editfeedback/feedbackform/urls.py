from django.conf.urls import url
from . import views
app_name='feedbackform'
urlpatterns = [
url(r'^$',views.feedbackform),
url(r'^feedback/',views.feedback),
url(r'^display/',views.display),
]
