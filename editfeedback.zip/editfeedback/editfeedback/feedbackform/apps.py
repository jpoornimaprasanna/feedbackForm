from django.apps import AppConfig


class FeedbackformConfig(AppConfig):
    name = 'feedbackform'
